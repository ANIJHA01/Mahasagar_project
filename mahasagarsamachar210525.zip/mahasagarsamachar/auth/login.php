<?php
    require 'includes/config.php'; 

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['login'])) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);

        $query = "SELECT user_id, username, password FROM user WHERE name = $username";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['login_success'] = true;

            header("Location: /mahasagarsamachar/");
            exit();
        } else {
            $_SESSION['login_error'] = "Invalid username or password.";
            header("Location: /mahasagarsamachar/");
            exit();
        }
    }
?>

    <div class="container-fluid">
        <div class="container animate-box fadeInUp animated-fast">
            <div class="bottom">
                <!-- form start -->
                <form action="login.php" method="POST">
                    <div class="row">
                        <div class="col-12 offset-md-0 col-md-12">
                            <div class="card mb-5">
                                <div class="card-header text-center">
                                    <h2>Admin-Login-Page</h2>
                                </div>
                                <div class="card-body">
                                    <div class="form-group mb-4">
                                        <label style="text-decoration:underline;">Username</label>
                                        <input type="text" name="username" class="form-control" placeholder="Enter Username" required>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label style="text-decoration:underline;">Password</label>
                                        <br>
                                        <input type="password" name="password" class="form-control" placeholder="Enter Password" required>
                                    </div>    
                                </div>
                                <div class="card-footer">
                                    <input type="hidden" name="form-name" value="user_login" />
                                    <input type="submit" name="login" class="btn btn-primary" value="Login" />
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
