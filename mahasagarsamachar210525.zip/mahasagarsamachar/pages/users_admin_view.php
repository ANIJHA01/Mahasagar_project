<div class="container-fluid">
		<div class="container animate-box">
			<div class="row">
				<div class="post-header">
					<div class="bread">
                        <ul class="breadcrumbs" id="breadcrumbs"><h2> User Management Panel </h2></ul>


                        
					</div>
				</div>
                <table id="usersTable" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>User ID</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Username</th>
                                <th>Role</th>
								<th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
								$sql = "SELECT * FROM user";
								$result = mysqli_query($db, $sql) or die("Query Failed.");

								if(mysqli_num_rows($result) > 0){
									while($row = mysqli_fetch_assoc($result)){
										echo "<tr>";
										echo "<td>" . $row['user_id'] . "</td>";
										echo "<td>" . htmlspecialchars($row['first_name']) . "</td>";
										echo "<td>" . htmlspecialchars($row['last_name']) . "</td>";
										echo "<td>" . htmlspecialchars($row['username']) . "</td>";
										echo "<td>";
										switch($row['role']){
											case 0: echo "User"; break;
											case 1: echo "Admin"; break;
											case 2: echo "Super Admin"; break;
											default: echo "Unknown"; break;
										}
										echo "</td>";
										echo "<td>";
										echo "<a href='edit_user.php?id=" . $row['user_id'] . "' class='btn btn-sm btn-primary'><i class='bi bi-pencil-square'></i></a> ";
										echo "<a href='delete_user.php?id=" . $row['user_id'] . "' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this user?\")'><i class='bi bi-trash'></i></a>";
										echo "</td>";
										echo "</tr>";
									}
								}
                            ?>
                        </tbody>
                </table> 
			</div>
		</div>
	</div>
	
	<!-- /**
		*
		* Bottom Section
		*
		* Most comments
		* Latest
		* Categories
		* Instagram
		* 
	*/ -->
	<div class="container-fluid">
		<div class="container animate-box">
			<div class="bottom margin-15">
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
						<div class="sidebar-widget">
							<div class="widget-title-cover">
								<h4 class="widget-title"><span>Most comments</span></h4>
							</div>
							<div class="latest_style_3">
								<div class="latest_style_3_item">
									<span class="item-count vertical-align">1.</span>
									<div class="alith_post_title_small">
										<a href='/single'><strong>Frtuitous spluttered unlike ouch vivid blinked
												far inside</strong></a>
									</div>
								</div>
								<div class="latest_style_3_item">
									<span class="item-count vertical-align">2.</span>
									<div class="alith_post_title_small">
										<a href='/single'><strong>Against and lantern where a and gnashed
												nefarious</strong></a>
									</div>
								</div>
								<div class="latest_style_3_item">
									<span class="item-count vertical-align">3.</span>
									<div class="alith_post_title_small">
										<a href='/single'><strong>Ouch oh alas crud unnecessary invaluable
												some</strong></a>
									</div>
								</div>
								<div class="latest_style_3_item">
									<span class="item-count vertical-align">4.</span>
									<div class="alith_post_title_small">
										<a href='/single'><strong>And far hey much hello and bashful one save
												less</strong></a>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
						<div class="sidebar-widget">
							<div class="widget-title-cover">
								<h4 class="widget-title"><span>Latest</span></h4>
							</div>
							<div class="latest_style_2">
								<?php
									$limit = 3;
									$sql_latest = "SELECT id, news_title, news_banner FROM news_posts ORDER BY id DESC LIMIT ?";
									$stmt_latest = $db->prepare($sql_latest);
									$stmt_latest->bind_param("i", $limit);
									$stmt_latest->execute();
									$result_latest = $stmt_latest->get_result();

									while ($row = $result_latest->fetch_assoc()) {
								?>
								<div class="latest_style_2_item">
									<figure class="alith_news_img">
										<a href='<?=SITE_URL?>news?id=<?php echo $row['id']; ?>'>
											<img alt="<?= htmlspecialchars($row['news_title']); ?>" src="<?= NEWS_UPLOAD_URL . $row['news_banner']; ?>" class="hover_grey">
										</a>
									</figure>
									<h3 class="alith_post_title">
										<a href='<?=SITE_URL?>news?id=<?php echo $row['id']; ?>'>
											<?= htmlspecialchars($row['news_title']); ?>
										</a>
									</h3>
								</div>
								<?php
									}
									$stmt_latest->close();
								?>
							</div>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
						<div class="sidebar-widget">
							<div class="widget-title-cover">
								<h4 class="widget-title"><span>Categories</span></h4>
							</div>
							<ul class="bottom_menu">
								<?php
									$sql = "SELECT * FROM main_categories WHERE post >= 1";
									$result = $db->query($sql) or die("Query Failed: category");

									if ($result->num_rows > 0) {
										while ($row = $result->fetch_assoc()) {
											$categoryID = $row['cat_id'];
											$categoryName = $row['cat_name'];
											
											$categoryURL = SITE_URL . "category?cid=" . $categoryID;

											$activeClass = (isset($_GET['category_id']) && $_GET['category_id'] == $categoryID) ? 
												'class="active" style="background-color: #ffecec5c; border-radius:30px;"' : '';
											echo "<li $activeClass><a href=\"$categoryURL\" class=\"\"><i class=\"fa fa-angle-right\"></i>&nbsp;&nbsp; $categoryName</a></li>";
										}
									}
								?>
							</ul>
						</div>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
						<div class="sidebar-widget">
							<div class="widget-title-cover">
								<h4 class="widget-title"><span>Instagram</span></h4>
							</div>
							<ul class="alith-instagram-grid-widget alith-clr alith-row alith-gap-10">
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
								<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
									<a class="" target="_blank" href="#">
										<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
									</a>
								</li>
							</ul>
						</div>
					</div>
				</div> <!--.row-->
			</div>
		</div>
	</div>