<link href="https://cdn.jsdelivr.net/npm/froala-editor@latest/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
<!-- Include Select2 CSS -->
<!-- <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" /> -->

<div class="AJtexteditor">
    <div class="container-fluid">
        <div class="container animate-box fadeInUp animated-fast">
            <div class="bottom">
                <!-- form start -->
                <form action=" " method="POST" enctype="multipart/form-data" onsubmit="submitEditorContent()">
                    <div class="row">
                        <div class="col-12 offset-md-0 col-md-12">
                            <div class="card mb-5">
                                <div class="card-header text-center">
                                    <h2>Add News</h2>
                                </div>
                                <div class="card-body">
                                    <!-- Title section -->
                                    <div class="form-group mb-4">
                                        <label for="post_title">Title</label>
                                        <input id="post_title" name="post_title" class="form-control" autocomplete="off" required>
                                    </div>
                                    <!-- Title section -->
                                    <div class="form-group mb-4">
                                        <label for="post_description">Description</label>
                                        <textarea name="post_description" id="post_description" class="form-control" required></textarea>
                                    </div>
                                    <!-- text-editor -->
                                    <div class="form-group mb-4">
                                        <div class="text-editor-container">
                                            <div class="text-editor-toolbar">
                                                <div class="text-editor-head">
                                                    <select class="animation" onchange="fileHandle(this.value); this.selectedIndex=0">
                                                        <option value="" selected="" hidden="" disabled="">File</option>
                                                        <option value="new">New file</option>
                                                        <option value="txt">Save as txt</option>
                                                        <option value="pdf">Save as pdf</option>
                                                    </select>
                                                    <select class="animation" onchange="formatDoc('formatBlock', this.value); this.selectedIndex=0;">
                                                        <option value="" selected="" hidden="" disabled="">Format</option>
                                                        <option value="h1">Heading 1</option>
                                                        <option value="h2">Heading 2</option>
                                                        <option value="h3">Heading 3</option>
                                                        <option value="h4">Heading 4</option>
                                                        <option value="h5">Heading 5</option>
                                                        <option value="h6">Heading 6</option>
                                                        <option value="p">Paragraph</option>
                                                    </select>
                                                    <select class="animation" onchange="formatDoc('fontSize', this.value); this.selectedIndex=0;">
                                                        <option value="" selected="" hidden="" disabled="">Font size</option>
                                                        <option value="1">Extra small</option>
                                                        <option value="2">Small</option>
                                                        <option value="3">Regular</option>
                                                        <option value="4">Medium</option>
                                                        <option value="5">Large</option>
                                                        <option value="6">Extra Large</option>
                                                        <option value="7">Big</option>
                                                    </select> 
                                                    <div class="color animation">
                                                        <span>Color</span>
                                                        <input type="color" oninput="formatDoc('foreColor', this.value); this.value='#000000';">
                                                    </div>
                                                    <div class="color animation">
                                                        <span>Background</span>
                                                        <input type="color" oninput="formatDoc('hiliteColor', this.value); this.value='#000000';">
                                                    </div>
                                                    <div class="color animation">
                                                        <button type="button" style="background: white;">Ai-selector</button>
                                                    </div>
                                                </div>
                                                <div class="btn-toolbar">
                                                    <button type="button" onclick="formatDoc('undo')"><i class='bx bx-undo' ></i></button>
                                                    <button type="button" onclick="formatDoc('redo')"><i class='bx bx-redo' ></i></button>
                                                    <button type="button" onclick="formatDoc('bold')"><i class='bx bx-bold'></i></button>
                                                    <button type="button" onclick="formatDoc('underline')"><i class='bx bx-underline' ></i></button>
                                                    <button type="button" onclick="formatDoc('italic')"><i class='bx bx-italic' ></i></button>
                                                    <button type="button" onclick="formatDoc('strikeThrough')"><i class='bx bx-strikethrough' ></i></button>
                                                    <button type="button" onclick="formatDoc('justifyLeft')"><i class='bx bx-align-left' ></i></button>
                                                    <button type="button" onclick="formatDoc('justifyCenter')"><i class='bx bx-align-middle' ></i></button>
                                                    <button type="button" onclick="formatDoc('justifyRight')"><i class='bx bx-align-right' ></i></button>
                                                    <button type="button" onclick="formatDoc('justifyFull')"><i class='bx bx-align-justify' ></i></button>
                                                    <button type="button" onclick="formatDoc('insertOrderedList')"><i class='bx bx-list-ol' ></i></button>
                                                    <button type="button" onclick="formatDoc('insertUnorderedList')"><i class='bx bx-list-ul' ></i></button>
                                                    <button type="button" onclick="addLink()"><i class='bx bx-link' ></i></button>
                                                    <button type="button" onclick="formatDoc('unlink')"><i class='bx bx-unlink' ></i></button>
                                                    <button type="button" id="show-code" data-active="false">&lt;/&gt;</button>
                                                    <button type="button" onclick="document.getElementById('imageUpload').click()"><i class='bx bxs-image-add' ></i></button>
                                                    <input type="file" id="imageUpload" accept="image/*" style="display:none;" onchange="insertImage(this)">
                                                    <!-- New table button -->
                                                    <button type="button" class="aj-button" onclick="insertTable()"><i class="bx bx-table"></i></button>
                                                </div>
                                            </div>
                                            <input type="hidden" name="Cname" id="hiddenContent">
                                            <?php
                                                include 'includes/config.php'; 

                                            $news_id = isset($_GET['id']) ? intval($_GET['id']) : null;

                                            if ($news_id) {
                                                $stmt = $db->prepare("SELECT news_content FROM news_posts WHERE id = ?");
                                                $stmt->bind_param("i", $news_id);
                                                $stmt->execute();
                                                $stmt->bind_result($news_content);
                                                $stmt->fetch();
                                                $stmt->close();
                                            } else {
                                                $news_content = "No content available!"; 
                                            }
                                            ?>
                                            <div id="text-editor-content" contenteditable="true" name="Cname">
                                                <?= $news_content; ?>
                                            </div>
                                            <input type="hidden" id="ajEditorId" value="">
                                            <input type="submit" class="btn btn-primary m-2" value="Submit" onclick="ajTextEditor()">
                                        </div>
                                    </div>
                                    <!-- Category dropdown -->
                                    <div class="form-group">
                                        <label for="exampleInputPassword1">Category</label>
                                        <select name="category" class="form-control">
                                            <option disabled selected> Select Category</option>
                                            <?php
                                                include "config.php";
                                                $sql = "SELECT * FROM main_categories";
                                                $result = mysqli_query($db, $sql) or die("Query Failed.");

                                                if(mysqli_num_rows($result) > 0){
                                                    while($row = mysqli_fetch_assoc($result)){
                                                    echo "<option value='{$row['cat_id']}'>" . strtoupper($row['cat_name']) . "</option>";
                                                    }
                                                }
                                            ?>
                                        </select>
                                    </div>
                                    <!-- Author section -->
                                    <div class="form-group mb-4">
                                        <label for="post_author">Author</label>
                                        <input id="post_author" name="post_author" class="form-control" autocomplete="off" required>
                                    </div>
                                    <!-- Tags section -->
                                    <div class="form-group">
                                        <label for="tags_id">Tags (If you want multi select thane press Cntrol + Click) </label>
                                        <select id="tags_id" name="tags_id[]" class="form-control" style="height:150px;" multiple>
                                            <?php
                                                $sql = "SELECT * FROM news_tags";
                                                $result = mysqli_query($db, $sql) or die("Query Failed.");

                                                if (mysqli_num_rows($result) > 0) {
                                                    while ($row = mysqli_fetch_assoc($result)) {
                                                        echo "<option value='{$row['tags_id']}'>" . strtoupper($row['tags_name']) . "</option>";
                                                    }
                                                }
                                            ?>
                                        </select>
                                    </div>


                                    <!-- image section -->
                                    <div class="form-group mb-4">
                                        <label for="fileToUpload">Post image</label>
                                        <input id="fileToUpload" type="file" accept="image/*" name="fileToUpload"
                                            onchange="previewImage(event)" required>
                                        <br>
                                        <img id="preview" alt="Preview Image" style=" width: 150px; height: auto;">
                                    </div>

                                    <!-- video section -->
                                    <div class="form-group mb-4">
                                        <label for="videoUpload">Upload Video (max 20MB, mp4 only)</label>
                                        <input id="videoUpload" type="file" accept="video/mp4" name="videoUpload" onchange="previewVideo(event)">
                                        <br>
                                        <video id="videoPreview" style="width: 200px; display: none; margin-top: 10px;" controls></video>
                                    </div>
                                    <div class="form-group mb-4">
                                        <label for="videoLink">Or Video Link (YouTube, Vimeo, etc.)</label>
                                        <input id="videoLink" type="url" name="videoLink" class="form-control" placeholder="https://">
                                        <small class="form-text text-muted">You can either upload a video or provide a video link. If both are provided, the uploaded video will be used.</small>
                                    </div>
                                    
                                </div>
                                <div class="card-footer">
                                    <input accept="image/*" id="imgInp" type="hidden" name="form-name"value="add_news_post" />
                                    <img id="blah" src="#" alt="Image preview" style="display: none; max-width: 100px;" />
                                    <input type="submit" name="submit" class="btn btn-primary" value="Save Post" />
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- <script src="script.js"></script>
      Include jQuery
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
Include Select2 JS
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script>
    Initialize Select2
    $(document).ready(function() {
        $('#tags_id').select2({
            placeholder: "Select Tags",
            allowClear: true,
            width: '100%'
        });
    });
</script> -->