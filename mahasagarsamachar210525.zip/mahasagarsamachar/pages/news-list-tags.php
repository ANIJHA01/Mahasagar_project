<div class="container-fluid">
	<div class="container animate-box">
		<div class="row">
			<div class="archive-header">
				<?php 
					$tagsID = isset($_GET['tid']) ? intval($_GET['tid']) : 0; 

					$tagsName = "Unknown Category"; 

					if ($tagsID > 0) {
						$sql = "SELECT tags_name FROM news_tags WHERE tags_id = $tagsID";
						$stmt = $db->prepare($sql);
						$stmt->execute();
						$result = $stmt->get_result();

						if ($row = $result->fetch_assoc()) {
							$tagsName = $row['tags_name'];
						}
					}
				?>
				<div class="archive-title">
					<h2><?php echo strtoupper($tagsName); ?></h2>
				</div>
				<div class="bread">
					<ul class="breadcrumbs" id="breadcrumbs">
						<li class="item-current item-cat"><a class='bread-link bread-cat' href='<?php echo BASE_URL; ?>' title='Home' onclick="window.location.href='/mahasagarsamachar/'; return false;">Home</a></li>
						<li class="separator separator-home"> /</li>
						<li class="item-current item-cat"><strong class="bread-current bread-cat">House &amp; Living</strong></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<?php
	include 'includes/config.php'; 

	$tags_id = isset($_GET['tid']) ? intval($_GET['tid']) : 0;
	$tags_name = "Unknown";
	$total_posts = 0;
	$limit = 5; 
	$page = isset($_GET['tag_page']) ? (int)$_GET['tag_page'] : 1;
	$offset = ($page - 1) * $limit;

	if ($tags_id > 0) {
		$sql = "SELECT tags_name FROM news_tags WHERE tags_id = ?";
		$stmt = $db->prepare($sql);
		$stmt->bind_param("i", $tags_id);
		$stmt->execute();
		$result = $stmt->get_result();

		if ($row = $result->fetch_assoc()) {
			$tags_name = $row['tags_name'];
		}
		$stmt->close();
	}

	$total_query = "SELECT COUNT(*) as total FROM news_posts WHERE FIND_IN_SET(?, tags_id)";
	$total_stmt = $db->prepare($total_query);
	$total_stmt->bind_param("i", $tags_id);
	$total_stmt->execute();
	$total_result = $total_stmt->get_result();
	$total_row = $total_result->fetch_assoc();
	$total_posts = $total_row['total'];
	$total_pages = ceil($total_posts / $limit);
	$total_stmt->close();

	$sql_posts = "SELECT * FROM news_posts WHERE FIND_IN_SET(?, tags_id) LIMIT ? OFFSET ?";
	$stmt_posts = $db->prepare($sql_posts);
	$stmt_posts->bind_param("iii", $tags_id, $limit, $offset);
	$stmt_posts->execute();
	$posts_result = $stmt_posts->get_result();
?>

<div class="container-fluid">
    <div class="container">
        <div class="primary margin-15">
            <div class="row">
                <div class="col-md-8">
                    <div class="post_list post_list_style_1">
                        <div class="grid grid_three_column">
                            <div class="grid-sizer">
                                <?php while ($post = $posts_result->fetch_assoc()) { ?>
                                    <article class="grid-item animate-box">
                                        <figure class="alith_news_img">
                                            <span class="post_meta_categories_label"><?= htmlspecialchars($tags_name); ?></span>
                                            <a href='<?= SITE_URL ?>news?id=<?= $post['id']; ?>'>
                                                <img src="<?= NEWS_UPLOAD_URL . $post['news_banner']; ?>" alt="Image not found" />
                                            </a>
                                        </figure>
                                        <h3 class="alith_post_title">
                                            <a href='<?= SITE_URL ?>news?id=<?= $post['id']; ?>'>
                                                <?= htmlspecialchars($post['news_title']); ?>
                                            </a>
                                        </h3>
                                        <div class="post_meta">
                                            <a class='meta_author_avatar' href='/page-author'>
                                                <img src="https://cdn.prod.website-files.com/62d84e447b4f9e7263d31e94/6399a4d27711a5ad2c9bf5cd_ben-sweet-2LowviVHZ-E-unsplash-1.jpeg" alt="author details" />
                                            </a>
                                            <span class="meta_author_name">
                                                <a href='<?= SITE_URL ?>news?id=<?= $post['id']; ?>'>
                                                    <?= htmlspecialchars($post['page_author']); ?>
                                                </a>
                                            </span>
                                            <span class="meta_date"><?= $post['added_dt']; ?></span>
                                        </div>
                                        <p class="alith_post_except"><?= htmlspecialchars(substr($post['news_description'], 0, 100)); ?>...</p>
                                        <div class="line-space"></div>
                                    </article>
                                <?php } ?>
                                <?php $stmt_posts->close(); ?>
                            </div>
                        </div>
                    </div>

                    <!-- Pagination -->
                    <div class="site-pagination animate-box">
                        <ul class="page-numbers">
                            <?php if ($page > 1) { ?>
                                <li><a href="?tid=<?= $tags_id ?>&tag_page=<?= $page - 1 ?>" class="prev page-numbers">PREV</a></li>
                            <?php } ?>

                            <?php for ($i = 1; $i <= $total_pages; $i++) { ?>
                                <li>
                                    <a href="?tid=<?= $tags_id ?>&tag_page=<?= $i ?>" class="page-numbers <?= ($i == $page) ? 'current' : '' ?>"><?= $i ?></a>
                                </li>
                            <?php } ?>

                            <?php if ($page < $total_pages) { ?>
                                <li><a href="?tid=<?= $tags_id ?>&tag_page=<?= $page + 1 ?>" class="next page-numbers">NEXT</a></li>
                            <?php } ?>
                        </ul>
                    </div>
				</div>
				<!--Start Sidebar-->
				<aside class="col-md-4">
					<div class="sidebar_right">
						<div class="sidebar-widget animate-box">
							<!-- Reset pointer and Display Popular Articles -->
							<?php
								$posts_result->data_seek(0);  // Reset the result pointer
							?>
							<div class="widget-title-cover">
								<h4 class="widget-title"><span>news-list Popular Articles</span></h4>
							</div>
							<?php
								$sql_posts = "SELECT * FROM news_posts WHERE tags_id = ? ORDER BY news_views DESC LIMIT 4";
								$stmt_posts = $db->prepare($sql_posts);
								$stmt_posts->bind_param("i", $tags_id);
								$stmt_posts->execute();
								$posts_result = $stmt_posts->get_result();
							?>

							<?php while ($post = $posts_result->fetch_assoc()) { ?>
								<div class="latest_style_1">
									<div class="latest_style_1_item">
										<div class="alith_post_title_small">
											<a href='<?=SITE_URL?>news?id=<?php echo $post['id']; ?>'>
												<strong><?=$post['news_title']?></strong>
											</a>
											<p class="meta">
												<span><?php echo $post['added_dt']; ?></span> 
												<span>👁️ <?= $post['news_views']; ?> Views</span>
											</p>
										</div>
										<figure class="alith_news_img">
											<a href='<?=SITE_URL?>news?id=<?php echo $post['id']; ?>'>
												<img src="<?=NEWS_UPLOAD_URL.$post['news_banner'];?>" alt="<?php echo $post['news_title']; ?>" />
											</a>
										</figure>
									</div>
								</div> <!--.sidebar-widget-->
							<?php } ?>

						<div class="sidebar-widget animate-box">
							<div class="widget-title-cover">
								<h4 class="widget-title"><span>Search</span></h4>
							</div>
							<form action="#" class="search-form" method="get" role="search">
								<label>
									<input type="search" name="s" value="" placeholder="Search …" class="search-field">
								</label>
								<input type="submit" value="Search" class="search-submit">
							</form>
						</div> <!--.sidebar-widget-->

						<?php
							$limit = 4;
							$trendingQuery = "SELECT id, news_title, news_banner, added_dt, news_views 
											FROM news_posts 
											ORDER BY news_views DESC 
											LIMIT {$limit}";

							$result = mysqli_query($db, $trendingQuery) or die("Query Failed: " . mysqli_error($db));

							if(mysqli_num_rows($result) > 0){
						?>
							<div class="sidebar-widget animate-box">
								<div class="widget-title-cover">
									<h4 class="widget-title"><span>Trending</span></h4>
								</div>
								<div class="latest_style_2">
									<?php 
									$count = 0;
									while($row = mysqli_fetch_assoc($result)) { 
										if ($count == 0) { // Pehli post (Sabse zyada views wali)
											?>
											<div class="latest_style_2_item_first">
												<figure class="alith_post_thumb_big">
													<a href='<?=SITE_URL?>news?id=<?= $row['id']; ?>'>
														<img src="<?= NEWS_UPLOAD_URL . $row['news_banner']; ?>" alt="<?= htmlspecialchars($row['news_title']); ?>" />
													</a>
												</figure>
												<h3 class="alith_post_title">
													<a href='<?=SITE_URL?>news?id=<?= $row['id']; ?>'>
														<strong><?= htmlspecialchars($row['news_title']); ?></strong>
													</a>
												</h3>
												<div class="post_meta">
													<span class="meta_date"><?= $row['added_dt']; ?></span>
													<span class="meta_views">👁️ <?= $row['news_views']; ?> Views</span>
												</div>
											</div>
											<?php
										} else { // Baaki 3 posts
											?>
											<div class="latest_style_2_item">
												<figure class="alith_news_img">
													<a href='<?=SITE_URL?>news?id=<?= $row['id']; ?>'>
														<img src="<?= NEWS_UPLOAD_URL . $row['news_banner']; ?>" alt="<?= htmlspecialchars($row['news_title']); ?>" />
													</a>
												</figure>
												<h3 class="alith_post_title">
													<a href='<?=SITE_URL?>news?id=<?= $row['id']; ?>'>
														<?= htmlspecialchars($row['news_title']); ?>
													</a>
												</h3>
												<div class="post_meta">
													<span class="meta_date"><?= $row['added_dt']; ?></span>
													<span class="meta_views">👁️ <?= $row['news_views']; ?> Views</span>
												</div>
											</div>
											<?php
										}
										$count++;
									} 
									?>
								</div>
							</div>
							<?php 
							}
							?> <!--.sidebar-widget-->

						<div class="sidebar-widget animate-box">
							<div class="widget-title-cover">
								<h4 class="widget-title"><span>Tags cloud</span></h4>
							</div>
							<div class="alith_tags_all">
								<?php 
									$tagSql = "SELECT * FROM news_tags";
									$tagResult = mysqli_query($db, $tagSql) or die("Query Failed: " . mysqli_error($db));
									if(mysqli_num_rows($tagResult) > 0) {
										while($tagRow = mysqli_fetch_assoc($tagResult)){
											$tagsID = $tagRow['tags_id'];
											$tagsName = $tagRow['tags_name'];
											
											$tagsURL = SITE_URL . "tags?tid=" . $tagsID;
											$categoryURL = SITE_URL . "category?cid=" . $categoryID;

											$activeClass = (isset($_GET['tags_id']) && $_GET['tags_id'] == $tagsID) ? 'active' : '';	
											echo "<a href='" . $tagsURL . "' class='alith_tagg'>" . $tagRow['tags_name'] . "</a>";
										}
									}
								?>
							</div>
						</div> <!--.sidebar-widget-->
					</div>
				</aside>
				<!--End Sidebar-->
			</div>
		</div> <!--.primary-->

	</div>
</div>
<!-- /**
	*
	* Bottom Section
	*
	* Most comments
	* Latest
	* Categories
	* Instagram
	* 
	*/ -->
<div class="container-fluid">
	<div class="container animate-box">
		<div class="bottom margin-15">
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
					<div class="sidebar-widget">
						<div class="widget-title-cover">
							<h4 class="widget-title"><span>Most comments</span></h4>
						</div>
						<div class="latest_style_3">
							<div class="latest_style_3_item">
								<span class="item-count vertical-align">1.</span>
								<div class="alith_post_title_small">
									<a href='/single'><strong>Frtuitous spluttered unlike ouch vivid blinked
											far inside</strong></a>
								</div>
							</div>
							<div class="latest_style_3_item">
								<span class="item-count vertical-align">2.</span>
								<div class="alith_post_title_small">
									<a href='/single'><strong>Against and lantern where a and gnashed
											nefarious</strong></a>
								</div>
							</div>
							<div class="latest_style_3_item">
								<span class="item-count vertical-align">3.</span>
								<div class="alith_post_title_small">
									<a href='/single'><strong>Ouch oh alas crud unnecessary invaluable
											some</strong></a>
								</div>
							</div>
							<div class="latest_style_3_item">
								<span class="item-count vertical-align">4.</span>
								<div class="alith_post_title_small">
									<a href='/single'><strong>And far hey much hello and bashful one save
											less</strong></a>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
					<div class="sidebar-widget">
						<div class="widget-title-cover">
							<h4 class="widget-title"><span>Latest</span></h4>
						</div>
						<div class="latest_style_2">
							<?php
								$limit = 3;
								$sql_latest = "SELECT id, news_title, news_banner FROM news_posts ORDER BY id DESC LIMIT ?";
								$stmt_latest = $db->prepare($sql_latest);
								$stmt_latest->bind_param("i", $limit);
								$stmt_latest->execute();
								$result_latest = $stmt_latest->get_result();

								while ($row = $result_latest->fetch_assoc()) {
							?>
							<div class="latest_style_2_item">
								<figure class="alith_news_img">
									<a href='<?=SITE_URL?>news?id=<?php echo $row['id']; ?>'>
										<img alt="<?= htmlspecialchars($row['news_title']); ?>" src="<?= NEWS_UPLOAD_URL . $row['news_banner']; ?>" class="hover_grey">
									</a>
								</figure>
								<h3 class="alith_post_title">
									<a href='<?=SITE_URL?>news?id=<?php echo $row['id']; ?>'>
										<?= htmlspecialchars($row['news_title']); ?>
									</a>
								</h3>
							</div>
							<?php
								}
								$stmt_latest->close();
							?>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
					<div class="sidebar-widget">
						<div class="widget-title-cover">
							<h4 class="widget-title"><span>Categories</span></h4>
						</div>
						<ul class="bottom_menu">
							<?php
								$sql = "SELECT * FROM main_categories WHERE post >= 1";
								$result = mysqli_query($db, $sql) or die("Query Failed.: category");

								if (mysqli_num_rows($result) > 0) {
									while ($row = $result->fetch_assoc()) {
										$categoryID = $row['cat_id'];
										$categoryName = $row['cat_name'];
										
										$categoryURL = SITE_URL . "category?cid=" . $categoryID;

										$activeClass = (isset($_GET['category_id']) && $_GET['category_id'] == $categoryID) ? 
											'class="active" style="background-color: #ffecec5c; border-radius:30px;"' : '';
										echo "<li $activeClass><a href=\"$categoryURL\" class=\"\"><i class=\"fa fa-angle-right\"></i>&nbsp;&nbsp; $categoryName</a></li>";
									}
								}
							?>
						</ul>
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-3">
					<div class="sidebar-widget">
						<div class="widget-title-cover">
							<h4 class="widget-title"><span>Instagram</span></h4>
						</div>
						<ul class="alith-instagram-grid-widget alith-clr alith-row alith-gap-10">
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
							<li class="wow fadeInUp alith-col-nr alith-clr alith-col-3 animated">
								<a class="" target="_blank" href="#">
									<img class="" title="" alt="" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Instagram_logo_2022.svg/1200px-Instagram_logo_2022.svg.png">
								</a>
							</li>
						</ul>
					</div>
				</div>
			</div> <!--.row-->
		</div>
	</div>
</div>