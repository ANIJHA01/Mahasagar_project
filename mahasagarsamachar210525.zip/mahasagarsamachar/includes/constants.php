<?php 

error_reporting(E_ALL);

ini_set('display_errors', 1);

define("SITE_URL", "http://localhost/mahasagarsamachar/");
define("ROOT_PATH", "C:/xampp/htdocs/mahasagarsamachar/");

define("BASE_URL", SITE_URL."assets/");
define("UPLOAD_URL", SITE_URL."uploads/");
define("NEWS_UPLOAD_URL", UPLOAD_URL."news_posts/");
define("ADS_UPLOAD_URL", UPLOAD_URL."news_ads/");
define("UPLOAD_PATH", ROOT_PATH."uploads/");
define("NEWS_UPLOAD_PATH", UPLOAD_PATH."news_posts/");
define("ADS_UPLOAD_PATH", UPLOAD_PATH."news_ads/");
