
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/../vendor/autoload.php'; 

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    session_start();

    // Optional: check admin role
    if (!isset($_SESSION['role']) || $_SESSION['role'] != 1) {
        die("Unauthorized access");
    }

    $action = $_POST['action'] ?? '';
    $news_id = intval($_POST['id'] ?? 0);

    if ($news_id <= 0 || empty($action)) {
        http_response_code(400);
        echo "Invalid request";
        exit();
    }

    // Fetch news info
    $newsQuery = $db->prepare("SELECT news_title, page_author FROM news_posts WHERE id = ?");
    $newsQuery->bind_param("i", $news_id);
    $newsQuery->execute();
    $result = $newsQuery->get_result();
    $news = $result->fetch_assoc();
    $newsQuery->close();

    if (!$news) {
        http_response_code(404);
        echo "News post not found";
        exit();
    }

    $response = [];
    $email = 'ajha43034@gmail.com';
    $subject = "";
    $message = "";

    if ($action === 'approve') {
        $sql = "UPDATE news_posts SET status = 'approved', deny_reason = NULL WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("i", $news_id);

        $subject = "News Approved: " . $news['news_title'];
        $message = "The news titled \"{$news['news_title']}\" by {$news['page_author']} has been approved.";
    } elseif ($action === 'deny') {
        $reason = trim($_POST['reason'] ?? '');
        if (empty($reason)) {
            http_response_code(400);
            echo "Deny reason is required.";
            exit();
        }

        $sql = "UPDATE news_posts SET status = 'denied', deny_reason = ? WHERE id = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("si", $reason, $news_id);

        $subject = "News Denied: " . $news['news_title'];
        $message = "The news titled \"{$news['news_title']}\" by {$news['page_author']} has been denied.\n\nReason: $reason";
    } else {
        http_response_code(400);
        echo "Invalid action";
        exit();
    }

    if ($stmt->execute()) {
        // Send email using PHPMailer
        $mail = new PHPMailer(true);
        try {
            // SMTP Settings
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'j9450773@gmail.com'; // <-- your Gmail
            $mail->Password   = 'vgfd duym arhk vfye';    // <-- Gmail App Password
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            // Sender & Recipient
            $mail->setFrom('ajha43034@gmail.com', 'News Admin');
            // $mail->addAddress($to); // To
            $mail->addAddress($email);

            // Email Content
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = nl2br($message); 
            $mail->AltBody = $message;        

            $mail->send();
        } catch (Exception $e) {
            error_log("Mailer Error: {$mail->ErrorInfo}");
        }

        $response["status"] = true;
    } else {
        $response["status"] = false;
        $response["error"] = $stmt->error;
    }

    $stmt->close();

    if ($response["status"]) {
        $_SESSION['status'] = "News has been successfully " . ($action === "approve" ? "approved" : "denied") . ".";
        $_SESSION['status_code'] = "success";
        echo "Success";
    } else {
        $_SESSION['status'] = "Failed to update news status.";
        $_SESSION['status_code'] = "error";
        http_response_code(500);
        echo $response["error"] ?? "Unknown error";
    }
}
?>
